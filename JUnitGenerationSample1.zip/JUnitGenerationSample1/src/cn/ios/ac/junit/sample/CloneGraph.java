package cn.ios.ac.junit.sample;

import java.util.*;

public class CloneGraph {
	public UndirectedGraphNode cloneGraph(UndirectedGraphNode node) {
		if (node == null) {
			return null;
		}
		Map<UndirectedGraphNode, UndirectedGraphNode> map = new HashMap<>();
//        List<UndirectedGraphNode> list = new ArrayList();
		return clone(node, map);
	}

	public UndirectedGraphNode clone(UndirectedGraphNode node, Map<UndirectedGraphNode, UndirectedGraphNode> map) {
		if (node == null) {
			return null;
		}
		if (map.containsKey(node)) {
			return map.get(node);
		}
		UndirectedGraphNode newNode = new UndirectedGraphNode(node.label);
		map.put(node, newNode);
		for (UndirectedGraphNode index : node.neighbors) {
			newNode.neighbors.add(clone(index, map));
		}
		return newNode;
	}
}
