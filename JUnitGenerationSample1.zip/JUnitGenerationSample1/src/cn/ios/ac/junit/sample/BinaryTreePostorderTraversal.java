package cn.ios.ac.junit.sample;

import java.util.ArrayList;

public class BinaryTreePostorderTraversal {
	public ArrayList<Integer> postorderTraversal(TreeNode root) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		if (root == null) {
			return list;
		}
		test(root, list);
		return list;
	}

	public void test(TreeNode node, ArrayList<Integer> list) {
		if (node.left != null) {
			test(node.left, list);
		}
		if (node.right != null) {
			test(node.right, list);
		}
		list.add(node.val);
	}
}
