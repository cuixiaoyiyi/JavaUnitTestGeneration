package cn.ios.ac.junit.sample;

public class SingleNumber {

	public int singleNumber(int[] nums) {
		int ones = 0;
		int twos = 0;
		int threes = 0;
		for (int num : nums) {
			twos = twos | (num & ones);
			ones = ones ^ num;
			threes = ones & twos;
			ones = ones & (~threes);
			twos = twos & (~threes);
		}
		int res = ones | twos;
		return res;
	}
}
