package cn.ios.ac.junit.sample;

import java.util.ArrayList;

// Definition for undirected graph.
public class UndirectedGraphNode {
	int label;
	ArrayList<UndirectedGraphNode> neighbors;

	UndirectedGraphNode(int x) {
		label = x;
		neighbors = new ArrayList<UndirectedGraphNode>();
	}
}