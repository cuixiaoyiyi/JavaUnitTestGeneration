package cn.ios.ac.junit.sample;

import java.util.*;

public class WordBreakLi {
	public ArrayList<String> list = new ArrayList<>();

	public ArrayList<String> wordBreak(String s, Set<String> dict) {
		DFS(s, dict, s.length(), "");
		return list;
	}

	private void DFS(String s, Set<String> dict, int index, String str) {
		if (index <= 0)
			if (str.length() > 0)
				list.add(str.substring(0, str.length() - 1));
		for (int i = index; i >= 0; i--) {
			if (dict.contains(s.substring(i, index)))
				DFS(s, dict, i, s.substring(i, index) + " " + str);
		}
	}
}