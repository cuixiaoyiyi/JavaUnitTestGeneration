package cn.ios.ac.junit.sample;

public class ReorderList {
	public void reorderList(ListNode head) {
		if (head == null || head.next == null)
			return;

		ListNode slow = head;
		ListNode fast = head;
		while (fast.next != null && fast.next.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		ListNode preMiddle = slow;
		ListNode precurr = slow.next;
		while (precurr.next != null) {
			ListNode current = precurr.next;
			precurr.next = current.next;
			current.next = preMiddle.next;
			preMiddle.next = current;
		}
		slow = head;
		fast = preMiddle.next;
		while (slow != preMiddle) {
			preMiddle.next = fast.next;
			fast.next = slow.next;
			slow.next = fast;
			slow = fast.next;
			fast = preMiddle.next;
		}
	}
}